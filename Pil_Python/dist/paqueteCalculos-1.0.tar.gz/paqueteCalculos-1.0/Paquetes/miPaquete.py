#xxxxxx------------------------------------------------------------->
#Modulo contenedor de operaciones matematicas generales
#xxxxxx------------------------------------------------------------->
def sumar(nm1, nm2):
	print("El Resultado de la suma es: ", nm1 + nm2);

def restar(nm1, nm2):
	print("EL Resultado de la Resta  es: ", nm1 + nm2);

def multiplicar(nm1, nm2):
	print("El Resultado de la Multiplicaion es: ", nm1 * nm2);

def dividir(dividendo, divisor):
	print("El Resultado de la Division es: ", dividendo / divisor);

def potencia(base, exponente):
	print("El resultado de la expondecia es: ", base**exponente);

def redondear(num):
	print("REdondeo: ", round(num));
	