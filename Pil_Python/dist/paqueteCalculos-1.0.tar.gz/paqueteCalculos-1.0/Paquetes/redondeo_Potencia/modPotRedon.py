#xxxxxx------------------------------------------------------------->
#Modulo contenedor de operaciones matematicas Redondeo y Potencia
#xxxxxx------------------------------------------------------------->
def potencia(base, exponente):
	print("El resultado de la expondecia es: ", base**exponente);

def redondear(num):
	print("REdondeo: ", round(num));