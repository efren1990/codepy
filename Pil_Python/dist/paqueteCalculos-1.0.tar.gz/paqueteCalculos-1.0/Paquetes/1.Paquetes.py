#xxxxxx------------------------------------------------------------->
#PAQUETES
#xxxxxx------------------------------------------------------------->
"""
¿QUE SON?
►Directorios donde se almacenaran modulos relacionados entre si.
►Una aplicacion compleja hecha en python por lo general esta construida
de forma modulada, es decir con modulos.
►Los modulos que tengan relacion entre si o tengan un mismo objetivo, lo
aconsejable es que esten almacenados en PAQUETES
►Los PAQUETES Permiten moverse de sitio en en la maquina dentro de la raiz de la app
►Los modulos no permiten moverse de sitio tienen que estar en el mismo sition
donde se esten llamando.

¿PARQ QUE SIRVEN?
►Para organizar y reutilizar los modulos

¿COMO SE CREAN PAQUETES?
►Se debe crear una carpeta y dentro de ella debe ir un archivo
con nombre __init__.py 

"""